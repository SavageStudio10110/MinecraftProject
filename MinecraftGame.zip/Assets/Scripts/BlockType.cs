public enum BlockType  : byte
{
    Air = 0,
    Dirt = 1,
    Cobblestone = 2,
    Stone = 3,
    Grass = 4,
    Bedrock = 5,
    Wood = 6,
    Log = 7,
    Sand = 8,
    Pumpkin = 9,
    CraftTable = 10,
    Water = 11
} 