﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameWorld : MonoBehaviour
{
    private const int ViewRadius = 5;

    public Dictionary<Vector2Int, ChunkData> ChunkDatas = new Dictionary<Vector2Int, ChunkData>();
    public ChunkRenderer ChunkPrefab;
    public TerrainGenerator Generator;
    public BlockDatabase Blocks;

    private Camera mainCamera;
    private Vector2Int currentPlayerChunk;

    [Header("Доступные блоки для выбора")]
    public List<BlockType> availableBlocks = new List<BlockType>();

    private BlockType selectedBlock = BlockType.Dirt; // Блок по умолчанию


    [Header("Interaction Settings")]
    public float interactionDistance = 5f; // Максимальная дистанция взаимодействия с блоками.
    public float minDistance = 1.5f; //Установка блока под себя

    public float placeInterval = 0.2f;
    public float destroyInterval = 0.2f;

    private float nextPlaceTime;
    private float nextDestroyTime;


    private void Start()
    {
        mainCamera = Camera.main;

        Generator.Init();

        StartCoroutine(Generate(false));
    }
    private IEnumerator Generate(bool wait)
    {
        int loadRadius = ViewRadius + 1;

        for (int x = currentPlayerChunk.x - loadRadius; x < currentPlayerChunk.x + loadRadius; x++) //y = 10 // ; <= ;
        {
            for (int y = currentPlayerChunk.y - loadRadius; y < currentPlayerChunk.y + loadRadius; y++) // y = 10 // ; <= ;
            {
                Vector2Int chunkPosition = new Vector2Int(x, y);
                if (ChunkDatas.ContainsKey(chunkPosition)) continue;

                LoadChunk(x, y, chunkPosition);

                if (wait) yield return null;
            }
        }

        for (int x = currentPlayerChunk.x - ViewRadius; x < currentPlayerChunk.x + ViewRadius; x++) //y = 10 // ; <= ;
        {
            for (int y = currentPlayerChunk.y - ViewRadius; y < currentPlayerChunk.y + ViewRadius; y++) // y = 10 // ; <= ;
            {
                Vector2Int chunkPosition = new Vector2Int(x, y);

                ChunkData chunkData = ChunkDatas[chunkPosition];

                if (chunkData.Renderer != null) continue;

                SpawnChunkRenderer(chunkData);

                if (wait) yield return new WaitForSecondsRealtime(0.2f);
            }
        }
    }

    private void LoadChunk(int x, int y, Vector2Int chunkPosition)
    {
        float xPos = chunkPosition.x * ChunkRenderer.ChunkWidth * ChunkRenderer.BlockScale;
        float zPos = chunkPosition.y * ChunkRenderer.ChunkWidth * ChunkRenderer.BlockScale;

        ChunkData chunkData = new ChunkData();
        chunkData.ChunkPosition = chunkPosition;
        chunkData.Blocks = Generator.GenerateTerrain((int)xPos, (int)zPos);

        ChunkDatas[chunkPosition] = chunkData; // Исправлено: теперь чанки всегда правильно добавляются
    }

    private void SpawnChunkRenderer(ChunkData chunkData)
    {
        float xPos = chunkData.ChunkPosition.x * ChunkRenderer.ChunkWidth * ChunkRenderer.BlockScale;
        float zPos = chunkData.ChunkPosition.y * ChunkRenderer.ChunkWidth * ChunkRenderer.BlockScale;

        var chunk = Instantiate(ChunkPrefab, new Vector3(xPos, 0, zPos), Quaternion.identity, transform);
        chunk.chunkData = chunkData;
        chunk.ParentWorld = this;

        chunkData.Renderer = chunk;
    }

    private void FixedUpdate()
    {
        Vector3Int playerWorldPos = Vector3Int.FloorToInt(mainCamera.transform.position / ChunkRenderer.BlockScale);
        Vector2Int playerChunk = GetChunkContainingBlock(playerWorldPos);

        if (playerChunk != currentPlayerChunk)
        {
            currentPlayerChunk = playerChunk;
            //StartCoroutine(Generate(true));
        }
        HandleBlockSelection();
        CheckInput();
    }
    private void OnDrawGizmos()
    {
        if (!Application.isPlaying) return;

        // Получаем блоки, в которых находится игрок
        (Vector3Int feetBlock, Vector3Int headBlock) = GetPlayerBlocks();

        // Настройка цвета для Gizmos
        Gizmos.color = Color.green;

        // Подсвечиваем нижний блок (под ногами)
        DrawBlockGizmo(feetBlock);

        // Подсвечиваем верхний блок (туловище и голова)
        Gizmos.color = Color.blue;
        DrawBlockGizmo(headBlock);
    }

    // Метод для отрисовки контура блока
    private void DrawBlockGizmo(Vector3Int blockPos)
    {
        Vector3 worldPos = (Vector3)blockPos * ChunkRenderer.BlockScale;
        Gizmos.DrawWireCube(worldPos + Vector3.one * 0.5f * ChunkRenderer.BlockScale, Vector3.one * ChunkRenderer.BlockScale);
    }

    public (Vector3Int feetBlock, Vector3Int headBlock) GetPlayerBlocks()
    {
        // Позиция центра игрока (камера)
        Vector3 playerCenter = mainCamera.transform.position;

        // Точная высота CharacterController (1.98)
        float characterHeight = 1.98f;

        // 1. Нижний блок — под ногами
        Vector3 feetPosition = playerCenter - new Vector3(0, characterHeight / 2, 0);
        Vector3Int feetBlock = WorldToBlockPosition(feetPosition);

        // 2. Верхний блок — всегда на один блок выше
        Vector3Int headBlock = feetBlock + Vector3Int.up;

        return (feetBlock, headBlock);
    }

    // Преобразуем мировую позицию в координаты блока
    private Vector3Int WorldToBlockPosition(Vector3 worldPos)
    {
        return Vector3Int.FloorToInt(worldPos / ChunkRenderer.BlockScale);
    }

    // Преобразуем мировую позицию в координаты блока

    private void HandleBlockSelection()
    {
        if (Input.anyKeyDown)
        {
            for (int i = 0; i < availableBlocks.Count; i++)
            {
                KeyCode key = KeyCode.Alpha1 + i;

                if (Input.GetKeyDown(key))
                {
                    selectedBlock = availableBlocks[i];
                    Debug.Log($"Выбран блок: {selectedBlock}");
                }
            }
        }
    }
    private void CheckInput()
    {
        if (Input.GetMouseButton(0) || Input.GetMouseButton(1))
        {
            bool isDestroying = Input.GetMouseButton(0);
            float currentTime = Time.time;

            // Проверка интервала
            if ((isDestroying && currentTime < nextDestroyTime) || (!isDestroying && currentTime < nextPlaceTime))
            {
                return; // Ждем окончания интервала
            }

            Ray ray = mainCamera.ViewportPointToRay(new Vector3(0.5f, 0.5f));

            if (Physics.Raycast(ray, out var hitInfo, interactionDistance))
            {
                Vector3 blockCenter = isDestroying
                    ? hitInfo.point - hitInfo.normal * ChunkRenderer.BlockScale / 2
                    : hitInfo.point + hitInfo.normal * ChunkRenderer.BlockScale / 2;

                Vector3Int blockWorldPos = Vector3Int.FloorToInt(blockCenter / ChunkRenderer.BlockScale);
                Vector2Int chunkPos = GetChunkContainingBlock(blockWorldPos);

                if (ChunkDatas.TryGetValue(chunkPos, out ChunkData chunkData))
                {
                    Vector3Int chunkOrigin = new Vector3Int(chunkPos.x, 0, chunkPos.y) * ChunkRenderer.ChunkWidth;
                    Vector3Int localPos = blockWorldPos - chunkOrigin;

                    if (isDestroying)
                    {
                        chunkData.Renderer.DestroyBlock(localPos);
                        nextDestroyTime = currentTime + destroyInterval; // Обновляем таймер разрушения
                    }
                    else
                    {
                        if (CanPlaceBlock(blockWorldPos))
                        {
                            chunkData.Renderer.SpawnBlock(localPos, selectedBlock);
                            nextPlaceTime = currentTime + placeInterval; // Обновляем таймер установки
                        }
                        else
                        {
                            Debug.Log("Установка блока невозможна.");
                        }
                    }
                }
            }
        }
    }


    public Vector2Int GetChunkContainingBlock(Vector3Int blockWorldPos)
    {
        Vector2Int chunkPosition = new Vector2Int(
            Mathf.FloorToInt((float)blockWorldPos.x / ChunkRenderer.ChunkWidth),
            Mathf.FloorToInt((float)blockWorldPos.z / ChunkRenderer.ChunkWidth) // z вместо y!
        );

        return chunkPosition;
    }


    private bool CanPlaceBlock(Vector3Int targetBlockPos)
    {
        // Получаем блоки, в которых находится игрок
        (Vector3Int feetBlock, Vector3Int headBlock) = GetPlayerBlocks();

        // Запрещаем установку, если целевой блок совпадает с блоками игрока
        if (targetBlockPos == feetBlock || targetBlockPos == headBlock)
        {
            Debug.Log("Нельзя ставить блок внутри игрока!");
            return false;
        }

        // Если блок вне зоны игрока — разрешаем установку
        return true;
    }

}