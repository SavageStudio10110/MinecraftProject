using System;
using UnityEngine;

[CreateAssetMenu(menuName = "World/GeneratorWorld")]
public class TerrainGenerator : ScriptableObject
{
    public float BaseHeight = 8;
    public NoiseOctaveSettings[] Octaves;
    public NoiseOctaveSettings DomainWarp;

    [Serializable]
    public class NoiseOctaveSettings
    {
        public FastNoiseLite.NoiseType NoiseType; 
        public float Frequency = 0.2f; 
        public float Amplitude = 1; 
    }

    private FastNoiseLite[] octaveNoises;
    private FastNoiseLite warpNoise;

    [Header("LevelSettings")]
    public int waterLevel = 12; // ������� ���� � ����


    public void Init()
    {
        octaveNoises = new FastNoiseLite[Octaves.Length];
        for (int i = 0; i < Octaves.Length; i++)
        {
            octaveNoises[i] = new FastNoiseLite();
            octaveNoises[i].SetNoiseType(Octaves[i].NoiseType);
            octaveNoises[i].SetFrequency(Octaves[i].Frequency);
        }

        warpNoise = new FastNoiseLite();
        warpNoise.SetNoiseType(DomainWarp.NoiseType);
        warpNoise.SetFrequency(DomainWarp.Frequency);
        warpNoise.SetDomainWarpAmp(DomainWarp.Amplitude);
    }


    public BlockType[] GenerateTerrain(float xOffset, float zOffset)
    {
        var result = new BlockType[ChunkRenderer.ChunkWidth * ChunkRenderer.ChunkHeight * ChunkRenderer.ChunkWidth];

        for (int x = 0; x < ChunkRenderer.ChunkWidth; x++)
        {
            for (int z = 0; z < ChunkRenderer.ChunkWidth; z++)
            {
                float worldX = x * ChunkRenderer.BlockScale + xOffset;
                float worldZ = z * ChunkRenderer.BlockScale + zOffset;

                float height = GetHeight(worldX, worldZ);
                float grassLayerHeight = 1 + octaveNoises[0].GetNoise(worldX, worldZ) * 0.05f;
                float dirtLayerHeight = 2 + octaveNoises[0].GetNoise(worldX, worldZ) * 0.05f;
                float stoneLayerHeight = 14 + octaveNoises[0].GetNoise(worldX, worldZ) * 0.05f;

                for (int y = 0; y < ChunkRenderer.ChunkHeight; y++)
                {
                    int index = x + y * ChunkRenderer.ChunkWidthSq + z * ChunkRenderer.ChunkWidth;

                    // ��������� ������ ��� ������� ����
                    if (y * ChunkRenderer.BlockScale < height)
                    {
                        if (height - y * ChunkRenderer.BlockScale < grassLayerHeight)
                        {
                            result[index] = BlockType.Grass;
                        }
                        else if (height - y * ChunkRenderer.BlockScale < dirtLayerHeight * 2)
                        {
                            result[index] = BlockType.Dirt;
                        }
                        else if (height - y * ChunkRenderer.BlockScale < stoneLayerHeight)
                        {
                            result[index] = BlockType.Stone;
                        }
                        else
                        {
                            result[index] = BlockType.Bedrock;
                        }
                    }
                    else if (y <= waterLevel) // ��������� ����
                    {
                        result[index] = BlockType.Water;
                    }
                    else
                    {
                        result[index] = BlockType.Air;
                    }
                }
            }
        }

        return result;
    }

    private float GetHeight(float x, float y)
    {
        warpNoise.DomainWarp(ref x, ref y);

        float result = BaseHeight;

        for (int i = 0; i < Octaves.Length; i++)
        {
            float noise = octaveNoises[i].GetNoise(x, y);
            result += noise * Octaves[i].Amplitude / 2;
        }

        return result;
    }
}