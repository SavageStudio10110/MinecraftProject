using System.Collections.Generic;
using UnityEngine;

public class BlockDatabase : ScriptableObject
{
    [SerializeField] private BlockInfo[] Blocks;

    public Dictionary<BlockType, BlockInfo> blockCached = new Dictionary<BlockType, BlockInfo>(); //Public

    private void OnEnable()
    {
        blockCached.Clear();

        foreach (var blockInfo in Blocks)
        {
            blockCached.Add(blockInfo.Type, blockInfo);
        }
    }

    public BlockInfo GetInfo(BlockType type)
    {
        if(blockCached.TryGetValue(type, out var blockInfo))
        {
            return blockInfo;
        }

        return null;
    }

}
