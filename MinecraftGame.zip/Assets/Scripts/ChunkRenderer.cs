using System;
using System.Collections.Generic;
using UnityEngine;


[RequireComponent(requiredComponent: typeof(MeshFilter), requiredComponent2: typeof(MeshRenderer))]
public class ChunkRenderer : MonoBehaviour
{
    public const int ChunkWidth = 16;
    public const int ChunkWidthSq = ChunkWidth*ChunkWidth;
    public const int ChunkHeight = 128;
    public const float BlockScale = 1f;

    public ChunkData chunkData;
    public GameWorld ParentWorld;

    public BlockDatabase Blocks;
    private Mesh chunkMesh;

    private ChunkData leftChunk;
    private ChunkData rightChunk;
    private ChunkData fwdChunk;
    private ChunkData backChunk;

    private List<Vector3> verticles = new List<Vector3>();
    private List<Vector2> uvs = new List<Vector2>();
    private List<int> triangles = new List<int>();

    

    public static Action<Vector2Int> UpdateChunk;

    private void OnEnable()
    {
        ChunkRenderer.UpdateChunk += UpdateThatChunk;
    }

    private void OnDisable()
    {
        ChunkRenderer.UpdateChunk -= UpdateThatChunk;
    }

    private void Start()
    {
        ParentWorld.ChunkDatas.TryGetValue(chunkData.ChunkPosition + Vector2Int.left, out leftChunk);
        ParentWorld.ChunkDatas.TryGetValue(chunkData.ChunkPosition + Vector2Int.right, out rightChunk);
        ParentWorld.ChunkDatas.TryGetValue(chunkData.ChunkPosition + Vector2Int.up, out fwdChunk);
        ParentWorld.ChunkDatas.TryGetValue(chunkData.ChunkPosition + Vector2Int.down, out backChunk);

        chunkMesh = new Mesh();

        RegenerateMesh();

        GetComponent<MeshFilter>().mesh = chunkMesh;
    }
    private void UpdateThatChunk(Vector2Int _chunkPos)
    {
       if (chunkData.ChunkPosition.x == _chunkPos.x)
       {
           if (chunkData.ChunkPosition.y == _chunkPos.y)
           {
                RegenerateMesh();
           }
       }
    }

    private void RegenerateMesh()
    {
        verticles.Clear();
        uvs.Clear();
        triangles.Clear();

        for (int y = 0; y < ChunkHeight; y++)
        {
            for (int x = 0; x < ChunkWidth; x++)
            {
                for (int z = 0; z < ChunkWidth; z++)
                {
                    GenerateBlock(x, y, z);
                }
            }
        }

        chunkMesh.triangles = Array.Empty<int>();
        chunkMesh.vertices = Array.Empty<Vector3>();

        chunkMesh.vertices = verticles.ToArray();
        chunkMesh.uv = uvs.ToArray();
        chunkMesh.triangles = triangles.ToArray();

        chunkMesh.Optimize();

        chunkMesh.RecalculateNormals();
        chunkMesh.RecalculateBounds();

        GetComponent<MeshCollider>().sharedMesh = chunkMesh;
    }

    public void SpawnBlock(Vector3Int blockPosition, BlockType blockType)
    {
        int index = GetBlockIndex(blockPosition);
        if (index < 0 || index >= chunkData.Blocks.Length) return; // �������� �� ����� �� ������� �������

        chunkData.Blocks[index] = blockType;
        RegenerateMesh();
        GetSideUpdated(blockPosition);
    }
    public void DestroyBlock(Vector3Int blockPosition)
    {
        int index = GetBlockIndex(blockPosition);
        if (index < 0 || index >= chunkData.Blocks.Length) return; // �������� �� ����� �� ������� �������

        chunkData.Blocks[index] = BlockType.Air;
        RegenerateMesh();
        GetSideUpdated(blockPosition);
    }

    private int GetBlockIndex(Vector3Int blockPosition)
    {
        return blockPosition.x + blockPosition.y * ChunkWidthSq + blockPosition.z * ChunkWidth;
    } 

    private void GetSideUpdated(Vector3Int blockPosition)
    {
        if (blockPosition.x == ChunkWidth - 1)
        {
            UpdateChunk?.Invoke(new Vector2Int(chunkData.ChunkPosition.x + 1, chunkData.ChunkPosition.y));
        }
        else if (blockPosition.x == 0)
        {
            UpdateChunk?.Invoke(new Vector2Int(chunkData.ChunkPosition.x - 1, chunkData.ChunkPosition.y));
        }

        if (blockPosition.z == ChunkWidth - 1)
        {
            UpdateChunk?.Invoke(new Vector2Int(chunkData.ChunkPosition.x, chunkData.ChunkPosition.y + 1));
        }
        else if (blockPosition.z == 0)
        {
            UpdateChunk?.Invoke(new Vector2Int(chunkData.ChunkPosition.x, chunkData.ChunkPosition.y - 1));
        }
    }


    private void GenerateBlock(int x, int y, int z)
    {
        var blockPosition = new Vector3Int(x, y, z);

        BlockType blockType = GetBlockAtPosition(blockPosition);
        if (GetBlockAtPosition(blockPosition) == 0) return;

        if (GetBlockAtPosition(blockPosition + Vector3Int.right) == 0)
        {
            GenerateRightSide(blockPosition);
            AddUvs(blockType, Vector3Int.right);
        }
        if (GetBlockAtPosition(blockPosition + Vector3Int.left) == 0)
        {
            GenerateLefttSide(blockPosition);
            AddUvs(blockType, Vector3Int.left);
        }
        if (GetBlockAtPosition(blockPosition + Vector3Int.forward) == 0)
        {
            GenerateFrontSide(blockPosition);
            AddUvs(blockType, Vector3Int.forward);
        }
        if (GetBlockAtPosition(blockPosition + Vector3Int.back) == 0)
        {
            GenerateBackSide(blockPosition);
            AddUvs(blockType, Vector3Int.back);
        }
        if (GetBlockAtPosition(blockPosition + Vector3Int.up) == 0)
        {
            GenerateTopSide(blockPosition);
            AddUvs(blockType, Vector3Int.up);
        }
        if (GetBlockAtPosition(blockPosition + Vector3Int.down) == 0)
        {
            GenerateBottomSide(blockPosition);
            AddUvs(blockType, Vector3Int.down);
        }
    }


    private BlockType GetBlockAtPosition(Vector3Int blockPosition)
    {
        if(blockPosition.x >= 0 && blockPosition.x < ChunkWidth && 
           blockPosition.y >= 0 && blockPosition.y < ChunkHeight &&
           blockPosition.z >= 0 && blockPosition.z < ChunkWidth)
        {
            int index = blockPosition.x + (blockPosition.y * ChunkWidthSq) + (blockPosition.z * ChunkWidth);
            if (index < 0 || index >= chunkData.Blocks.Length) return BlockType.Air; // ������ �� ������ �� ������� �������

            return chunkData.Blocks[index];
        }
        else
        {
            if (blockPosition.y < 0 || blockPosition.y >= ChunkHeight) return BlockType.Air;


            if (blockPosition.x < 0)
            {
                if (leftChunk == null)
                    return BlockType.Air;

                blockPosition.x += ChunkWidth;

                int index = blockPosition.x + (blockPosition.y * ChunkWidthSq) + (blockPosition.z * ChunkWidth);
                if (index < 0 || index >= chunkData.Blocks.Length) return BlockType.Air; // ������ �� ������ �� ������� �������

                return leftChunk.Blocks[index];
            }

            if (blockPosition.x >= ChunkWidth)
            {
                if (rightChunk == null)
                    return BlockType.Air;

                blockPosition.x -= ChunkWidth;

                int index = blockPosition.x + (blockPosition.y * ChunkWidthSq) + (blockPosition.z * ChunkWidth);
                if (index < 0 || index >= chunkData.Blocks.Length) return BlockType.Air; // ������ �� ������ �� ������� �������

                return rightChunk.Blocks[index];
            }

            if (blockPosition.z < 0)
            {
                if (backChunk == null)
                    return BlockType.Air;

                blockPosition.z += ChunkWidth;

                int index = blockPosition.x + (blockPosition.y * ChunkWidthSq) + (blockPosition.z * ChunkWidth);
                if (index < 0 || index >= chunkData.Blocks.Length) return BlockType.Air; // ������ �� ������ �� ������� �������

                return backChunk.Blocks[index];
            }

            if (blockPosition.z >= ChunkWidth)
            {
                if (fwdChunk == null)
                    return BlockType.Air;

                blockPosition.z -= ChunkWidth;

                int index = blockPosition.x + (blockPosition.y * ChunkWidthSq) + (blockPosition.z * ChunkWidth);
                if (index < 0 || index >= chunkData.Blocks.Length) return BlockType.Air; // ������ �� ������ �� ������� �������

                return fwdChunk.Blocks[index];
            }

            return BlockType.Air;
        }
    }

    private void GenerateRightSide(Vector3Int blockPosition)
    {
        verticles.Add(item: (new Vector3(x: 1, y: 0, z: 0) + (Vector3)blockPosition) * BlockScale);
        verticles.Add(item: (new Vector3(x: 1, y: 1, z: 0) + (Vector3)blockPosition) * BlockScale);
        verticles.Add(item: (new Vector3(x: 1, y: 0, z: 1) + (Vector3)blockPosition) * BlockScale);
        verticles.Add(item: (new Vector3(x: 1, y: 1, z: 1) + (Vector3)blockPosition) * BlockScale);

        AddLastVerticlesSquare();
    }
    private void GenerateLefttSide(Vector3Int blockPosition)
    {
        verticles.Add(item: (new Vector3(x: 0, y: 0, z: 0) + (Vector3)blockPosition) * BlockScale);
        verticles.Add(item: (new Vector3(x: 0, y: 0, z: 1) + (Vector3)blockPosition) * BlockScale);
        verticles.Add(item: (new Vector3(x: 0, y: 1, z: 0) + (Vector3)blockPosition) * BlockScale);
        verticles.Add(item: (new Vector3(x: 0, y: 1, z: 1) + (Vector3)blockPosition) * BlockScale);

        AddLastVerticlesSquare();
    }
    private void GenerateFrontSide(Vector3Int blockPosition)
    {
        verticles.Add(item: (new Vector3(x: 0, y: 0, z: 1) + (Vector3)blockPosition) * BlockScale);
        verticles.Add(item: (new Vector3(x: 1, y: 0, z: 1) + (Vector3)blockPosition) * BlockScale);
        verticles.Add(item: (new Vector3(x: 0, y: 1, z: 1) + (Vector3)blockPosition) * BlockScale);
        verticles.Add(item: (new Vector3(x: 1, y: 1, z: 1) + (Vector3)blockPosition) * BlockScale);

        AddLastVerticlesSquare();
    }
    private void GenerateBackSide(Vector3Int blockPosition)
    {
        verticles.Add(item: (new Vector3(x: 0, y: 0, z: 0) + (Vector3)blockPosition) * BlockScale);
        verticles.Add(item: (new Vector3(x: 0, y: 1, z: 0) + (Vector3)blockPosition) * BlockScale);
        verticles.Add(item: (new Vector3(x: 1, y: 0, z: 0) + (Vector3)blockPosition) * BlockScale);
        verticles.Add(item: (new Vector3(x: 1, y: 1, z: 0) + (Vector3)blockPosition) * BlockScale);

        AddLastVerticlesSquare();
    }
    private void GenerateTopSide(Vector3Int blockPosition)
    {
        verticles.Add(item: (new Vector3(x: 0, y: 1, z: 0) + (Vector3)blockPosition) * BlockScale);
        verticles.Add(item: (new Vector3(x: 0, y: 1, z: 1) + (Vector3)blockPosition) * BlockScale);
        verticles.Add(item: (new Vector3(x: 1, y: 1, z: 0) + (Vector3)blockPosition) * BlockScale);
        verticles.Add(item: (new Vector3(x: 1, y: 1, z: 1) + (Vector3)blockPosition) * BlockScale);

        AddLastVerticlesSquare();
    }
    private void GenerateBottomSide(Vector3Int blockPosition)
    {
        verticles.Add(item: (new Vector3(x: 0, y: 0, z: 0) + (Vector3)blockPosition) * BlockScale);
        verticles.Add(item: (new Vector3(x: 1, y: 0, z: 0) + (Vector3)blockPosition) * BlockScale);
        verticles.Add(item: (new Vector3(x: 0, y: 0, z: 1) + (Vector3)blockPosition) * BlockScale);
        verticles.Add(item: (new Vector3(x: 1, y: 0, z: 1) + (Vector3)blockPosition) * BlockScale);

        AddLastVerticlesSquare();
    }


    private void AddLastVerticlesSquare()
    {

        triangles.Add(item: verticles.Count - 4);
        triangles.Add(item: verticles.Count - 3);
        triangles.Add(item: verticles.Count - 2);

        triangles.Add(item: verticles.Count - 3);
        triangles.Add(item: verticles.Count - 1);
        triangles.Add(item: verticles.Count - 2);
    }

    private void AddUvs(BlockType blockType, Vector3Int normal)
    {
        Vector2 uv;

        BlockInfo info = Blocks.GetInfo(blockType);

        if (info != null)
        {
            uv = info.GetPixelOffset(normal) / 256;
        }
        else
        {
            uv = new Vector2(10 * 16 / 256f, 14 * 16 / 256f);
        }


        for (int i = 0; i < 4; i++)
        {
            uvs.Add(uv);
        }
    }
}


//if (blockType == BlockType.Dirt)
//{
//    uv = new Vector2(208f / 256f, 80f / 256f);
//}
//else if (blockType == BlockType.Stone)
//{
//    uv = new Vector2(16f / 256f, 240f / 256f);
//}
//else if(blockType == BlockType.Cobblestone)
//{

//}
//else
//{
//    uv = new Vector2(160f / 256f, 224f / 256f);
//}

//� ����� ������ ��� ��������� 16 �� 1 ����� ���������� ������ ���� �� �������� � �� ������


//if (blockType == BlockType.Dirt)
//{
//    uv = new Vector2(2 * 16 / 256f, 15 * 16 / 256f);
//}
//else if (blockType == BlockType.Grass)
//{
//    uv = normal == Vector3Int.up ? new Vector2(0 * 16 / 256f, 15 * 16 / 256f) :
//        normal == Vector3Int.down ? new Vector2(2 * 16 / 256f, 15 * 16 / 256f) :
//        new Vector2(3 * 16 / 256f, 15 * 16 / 256f);
//}
//else if (blockType == BlockType.Stone)
//{
//    uv = new Vector2(6 * 16 / 256f, 15 * 16 / 256f);
//}
//else if (blockType == BlockType.Cobblestone)
//{
//    uv = new Vector2(1 * 16 / 256f, 15 * 16 / 256f);
//}
//else if (blockType == BlockType.Bedrock)
//{
//    uv = new Vector2(0 * 16 / 256f, 14 * 16 / 256f);
//}
//else
//{
//    uv = new Vector2(10 * 16 / 256f, 14 * 16 / 256f);
//}